# BetterDiscord Injector

You're probably looking for the main app, [click here](https://github.com/BetterDiscord/BetterDiscord) to go there.