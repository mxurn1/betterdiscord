import DiscordModules from "./discordmodules";
export default DiscordModules.ReactDOM;