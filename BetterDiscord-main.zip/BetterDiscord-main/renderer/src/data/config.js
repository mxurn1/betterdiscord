export default {
    version: process.env.__VERSION__,
    release: {assets: []},

    // Get from main process
    path: "",
    appPath: "",
    userData: ""
};