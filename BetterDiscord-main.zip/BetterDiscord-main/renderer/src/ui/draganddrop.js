/* 
<div class="bd-drop-container-wrap">
    <div class="bd-drop-container">
        <div class="bd-drop-icon"></div>
        <div class="bd-drop-title">Install Addon</div>
        <div class="bd-drop-message">Installs this plugin automatically</div>
    </div>
</div>
*/

/*
.bd-drop-container-wrap {
    display: none;
    justify-content: center;
    align-items: center;
    background: rgba(0,0,0,0.7);
    z-index: 1000;
    width: 100%;
}

.bd-drop-container {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    background: #3E82E5;
    padding: 20px;
    border-radius: 20px;
}

.bd-drop-icon {
    background: url('https://maxcdn.icons8.com/Share/icon/p1em/Very_Basic/plus1600.png');
    background-size: contain;
    height: 100px;
    width: 100px;
    filter: invert();
}

.bd-drop-title {
    color: white;
    font-weight: 600;
    font-size: 24px;
    margin-top: 8px
}

.bd-drop-message {
    color: white;
    margin-top: 8px;
}
*/